import 'package:tracky/models/expense.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class DatabaseHelper {
  static Database? _database;
  static const String _tableName = 'expenses';

  Future<Database> get database async {
    if (_database != null) {
      return _database!;
    }
    _database = await initializeDatabase();
    return _database!;
  }

  Future<Database> initializeDatabase() async {
    final String path = join(await getDatabasesPath(), 'expenses.db');
    return openDatabase(
      path,
      version: 1,
      onCreate: (Database db, int version) async {
        await db.execute(
          "CREATE TABLE $_tableName("
          "id TEXT PRIMARY KEY,"
          "title TEXT,"
          "amount REAL,"
          "date TEXT,"
          "category TEXT,"
          "comment TEXT,"
          "type TEXT,"
          "createdAt DATETIME"
          ")",
        );
      },
    );
  }

  Future<void> insertExpense(Expense expense) async {
    final Database db = await database;
    await db.insert(_tableName, expense.toMap());
  }

  Future<void> deletExpense(Expense expense) async {
    final Database db = await database;
    await db.delete(
      _tableName,
      where: 'id = ?',
      whereArgs: [expense.id],
    );
  }

  Future<List<Expense>> getExpenses() async {
    final Database db = await database;
    final List<Map<String, dynamic>> maps =
        await db.query(_tableName, orderBy: "createdAt DESC");
    return List.generate(maps.length, (i) {
      return Expense(
        id: maps[i]['id'],
        title: maps[i]['title'],
        category: Category.values.byName(maps[i]['category']),
        amount: maps[i]['amount'],
        date: DateTime.parse(maps[i]['date']),
        comment: maps[i]['comment'],
        type: maps[i]['type'],
        createdAt: DateTime.parse(maps[i]['createdAt']),
      );
    });
  }

  Future<double> getBalance() async {
    final Database db = await database;
    final drResult = await db.rawQuery(
        'SELECT SUM(amount) as total FROM $_tableName where type = ?', ['dr']);
    final crResult = await db.rawQuery(
        'SELECT SUM(amount) as total FROM $_tableName where type = ?', ['cr']);
    double totalDr =
        drResult.first['total'] != null ? drResult.first['total'] as double : 0;
    double totalcr =
        crResult.first['total'] != null ? crResult.first['total'] as double : 0;
    double totalBalance = totalcr - totalDr;
    return totalBalance;
  }
}
