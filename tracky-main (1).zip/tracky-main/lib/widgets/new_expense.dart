import 'package:tracky/models/expense.dart';
import 'package:flutter/material.dart';

class NewExpense extends StatefulWidget {
  const NewExpense({super.key, required this.onAddExpense});

  final void Function(Expense expense) onAddExpense;

  @override
  State<NewExpense> createState() {
    return _NewExpenseState();
  }
}

class _NewExpenseState extends State<NewExpense> {
  final _titleController = TextEditingController();
  final _commentController = TextEditingController();
  final _amountController = TextEditingController();
  DateTime? _selectedDate = DateTime.now();
  Category? _selectedCategory = Category.work;
  String _selectedType = 'dr';
  void _presentDatePicker() async {
    final now = DateTime.now();
    final firstDate = DateTime(now.year - 1, now.month, now.day);
    final pickedDate = await showDatePicker(
      context: context,
      firstDate: firstDate,
      lastDate: now,
      initialDate: now,
    );
    if (pickedDate != null) {
      setState(() {
        _selectedDate = pickedDate;
      });
    }
  }

  void _submitHandler() {
    final enteredAmount = double.tryParse(_amountController.text);

    final amountIsInValid = (enteredAmount == null || enteredAmount <= 0);
    if (_titleController.text.trim().isEmpty || amountIsInValid) {
      showDialog(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text("Invalid input"),
          content: const Text("Please enter valid inputs"),
          actions: [
            TextButton(
                onPressed: () {
                  Navigator.pop(ctx);
                },
                child: const Text("okay"))
          ],
        ),
      );
      return;
    }

    widget.onAddExpense(
      Expense(
        amount: enteredAmount,
        date: _selectedDate!,
        title: _titleController.text,
        category: _selectedCategory!,
        comment: _commentController.text,
        type: _selectedType,
        createdAt: DateTime.now(),
      ),
    );
    Navigator.pop(context);
  }

  @override
  void dispose() {
    _titleController.dispose();
    _commentController.dispose();
    _amountController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final keyboardSpace = MediaQuery.of(context).viewInsets.bottom;
    return SizedBox(
      height: double.infinity,
      width: double.infinity,
      child: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.fromLTRB(16, 40, 16, 16 + keyboardSpace),
          child: Column(
            children: [
              const Text("Add new expense",
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 22)),
              TextField(
                maxLength: 50,
                controller: _titleController,
                keyboardType: TextInputType.name,
                decoration: const InputDecoration(
                  label: Text(
                    "Title",
                  ),
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Expanded(
                    child: TextField(
                      controller: _amountController,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(
                        prefixText: '₹',
                        label: Text(
                          "Amount",
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(
                    width: 25,
                  ),
                  Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(100),
                      // color: Theme.of(context).colorScheme.primaryContainer,
                      border: Border.all(
                          color:
                              Theme.of(context).colorScheme.secondaryContainer,
                          width: 2),
                    ),
                    padding: const EdgeInsets.symmetric(horizontal: 40),
                    child: DropdownButton(
                        value: _selectedCategory,
                        items: Category.values
                            .map(
                              (cat) => DropdownMenuItem(
                                value: cat,
                                child: Text(
                                  cat.name.toUpperCase(),
                                ),
                              ),
                            )
                            .toList(),
                        onChanged: (value) {
                          setState(() {
                            _selectedCategory = value;
                          });
                        }),
                  ),
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: ListTile(
                      horizontalTitleGap: 0,
                      title: const Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Icon(
                            Icons.trending_up,
                            color: Colors.red,
                          ),
                          Text("Debit")
                        ],
                      ),
                      leading: Radio(
                          value: "dr",
                          groupValue: _selectedType,
                          onChanged: (String? val) {
                            setState(() {
                              _selectedType = val!;
                            });
                          }),
                    ),
                  ),
                  const SizedBox(
                    width: 40,
                  ),
                  Expanded(
                    child: ListTile(
                      horizontalTitleGap: 0,
                      title: const Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Icon(
                            Icons.trending_down,
                            color: Colors.green,
                          ),
                          Text("Credit")
                        ],
                      ),
                      leading: Radio(
                          value: "cr",
                          groupValue: _selectedType,
                          onChanged: (String? val) {
                            setState(() {
                              _selectedType = val!;
                            });
                          }),
                    ),
                  ),
                ],
              ),
              TextField(
                maxLength: 250,
                controller: _commentController,
                keyboardType: TextInputType.name,
                decoration: const InputDecoration(
                  label: Text(
                    "Comment",
                  ),
                ),
              ),
              const SizedBox(
                height: 16,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Text(
                            _selectedDate == null
                                ? "No Date Selected"
                                : formatter.format(_selectedDate!),
                            style: const TextStyle(fontSize: 17),
                          ),
                          IconButton(
                              onPressed: _presentDatePicker,
                              icon: const Icon(Icons.calendar_month))
                        ]),
                  ),
                  // const Spacer(),
                  TextButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      child: const Text("Cancel")),
                  ElevatedButton(
                    onPressed: _submitHandler,
                    child: const Text("Save"),
                  ),
                  // ElevatedButton(onPressed: onPressed, child: child)
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}
