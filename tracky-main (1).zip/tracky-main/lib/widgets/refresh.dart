import 'package:flutter/material.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';

class PullToRefresh extends StatefulWidget {
  const PullToRefresh({
    super.key,
    required this.child,
    required this.onRefresh,
  });
  final Widget child;
  final Function onRefresh;

  @override
  State<PullToRefresh> createState() => _PullToRefreshState();
}

class _PullToRefreshState extends State<PullToRefresh> {
  final RefreshController _refreshController = RefreshController();

  void _onLoading() async {
    Future.delayed(const Duration(milliseconds: 1000)).then((value) {
      if (mounted) {
        _refreshController.loadComplete();
      }
    });
  }

  Future<void> _onRefresh() async {
    Future.delayed(const Duration(milliseconds: 1500)).then((value) {
      if (mounted) {
        widget.onRefresh();
        _refreshController.refreshCompleted();
      }
    });
  }

  @override
  void dispose() {
    _refreshController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SmartRefresher(
      physics: const BouncingScrollPhysics(),
      controller: _refreshController,
      header: ClassicHeader(
        refreshingIcon: SizedBox(
          height: 20,
          width: 20,
          child: CircularProgressIndicator(
            color: Theme.of(context).colorScheme.primary,
            strokeWidth: 1.5,
          ),
        ),
      ),
      onLoading: _onLoading,
      enablePullDown: true,
      onRefresh: _onRefresh,
      child: widget.child,
    );
  }
}
