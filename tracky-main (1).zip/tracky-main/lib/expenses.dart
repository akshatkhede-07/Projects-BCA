import 'package:flutter/material.dart';
import 'package:tracky/helpers/db_helper.dart';
import 'package:tracky/widgets/chart/chart.dart';
import 'package:tracky/widgets/expenses_list.dart';
import 'package:tracky/models/expense.dart';
import 'package:tracky/widgets/new_expense.dart';
import 'package:tracky/widgets/refresh.dart';

class Expenses extends StatefulWidget {
  const Expenses({super.key});
  @override
  State<Expenses> createState() {
    return _ExpensesState();
  }
}

class _ExpensesState extends State<Expenses> {
  final DatabaseHelper databaseHelper = DatabaseHelper();
  double? balance;

  // final List<Expense> _expenses = [
  //   Expense(
  //       amount: 140,
  //       date: DateTime.now(),
  //       title: "Lunch",
  //       category: Category.food),
  //   Expense(
  //       amount: 140,
  //       date: DateTime.now(),
  //       title: "Lunch",
  //       category: Category.food),
  //   Expense(
  //       amount: 140,
  //       date: DateTime.now(),
  //       title: "Lunch",
  //       category: Category.food),
  //   Expense(
  //       amount: 140,
  //       date: DateTime.now(),
  //       title: "Lunch",
  //       category: Category.food),
  // ];
  List<Expense> _expenses = [];

  @override
  void initState() {
    super.initState();
    _fetchExpenses(); // Fetch expenses when the widget initializes
  }

  Future<void> _fetchExpenses() async {
    _fetchBalance();
    List<Expense> fetchedExpenses = await databaseHelper.getExpenses();
    print(fetchedExpenses.toString());
    setState(() {
      _expenses = fetchedExpenses;
    });
  }

  Future<void> _fetchBalance() async {
    double fetchedBalance = await databaseHelper.getBalance();
    setState(() {
      balance = fetchedBalance;
    });
  }

  void _openAddExpenseOverlay() {
    showModalBottomSheet(
      isScrollControlled: true,
      useSafeArea: true,
      context: context,
      builder: (ctx) => NewExpense(
        onAddExpense: _addExpense,
      ),
    );
  }

  void _addExpense(Expense expense) async {
    await databaseHelper.insertExpense(expense);
    _fetchExpenses();
  }

  void _removeExpense(
    Expense expense, {
    ScaffoldMessengerState? scaffoldMessenger,
  }) async {
    scaffoldMessenger ??= ScaffoldMessenger.of(context);
    await databaseHelper.deletExpense(expense);
    _fetchExpenses();
    scaffoldMessenger.clearSnackBars();
    scaffoldMessenger.showSnackBar(
      SnackBar(
        duration: const Duration(seconds: 4),
        content: const Text("Expense deleted"),
        action: SnackBarAction(
          label: "undo",
          onPressed: () {
            _addExpense(expense);
          },
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;

    Widget mainContent = const Center(
      child: Text("No expenses found!"),
    );
    if (_expenses.isNotEmpty) {
      mainContent = ExpensesList(
        expenses: _expenses,
        onRemoveExpense: _removeExpense,
      );
    }
    Widget layout = Column(
      children: [
        Chart(
          expenses: _expenses,
        ),
        Expanded(
          child: mainContent,
        ),
      ],
    );

    if (width > 600) {
      layout = Row(
        children: [
          Expanded(
            child: Chart(
              expenses: _expenses,
            ),
          ),
          Expanded(
            child: mainContent,
          ),
        ],
      );
    }

    return (Scaffold(
        appBar: AppBar(
          title: balance != null
              ? Row(
                  children: [
                    const Text(
                      "Tracky",
                      style: TextStyle(fontSize: 24),
                    ),
                    const SizedBox(
                      width: 16,
                    ),
                    const Icon(
                      Icons.account_balance_wallet,
                      color: Colors.white,
                    ),
                    const SizedBox(width: 5),
                    Text(
                      balance.toString(),
                      style: const TextStyle(color: Colors.white),
                    ),
                  ],
                )
              : const Text(
                  "Tracky",
                  style: TextStyle(fontSize: 24),
                ),
          actions: [
            IconButton(
                onPressed: _openAddExpenseOverlay,
                icon: const Icon(
                  Icons.add,
                  color: Colors.white,
                ))
          ],
        ),
        body: PullToRefresh(
          onRefresh: _fetchExpenses,
          child: layout,
        )));
  }
}
